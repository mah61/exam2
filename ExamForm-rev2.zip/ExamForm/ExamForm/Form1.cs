﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamForm
{
    public partial class frmRegist : Form
    {
        public frmRegist()
        {
            InitializeComponent();
        }

        private void btnClearF_Click(object sender, EventArgs e)
        {
            txtFN.Text = " ";
            txtLN.Text = " ";
            txtTelNo.Text = " ";
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            
            if (txtFN.Text == string.Empty)
            {

                MessageBox.Show("please fill in the first name");
            }

            if (txtLN.Text == string.Empty) {

                MessageBox.Show("please fill in the last name");

            }

            if (txtTelNo.Text == string.Empty) {

                MessageBox.Show("please fill in the telephone number");

            }

            if (txtFN.Text != string.Empty && txtLN.Text != string.Empty && txtTelNo.Text != string.Empty) {

                string path = @"C:\Users\1896192\Desktop\Mahnaz\User.txt";

                string content = "first name: " + txtFN.Text + "last name: " + txtLN.Text + "telephone: " + txtTelNo.Text;
                
               FileStream stream = new FileStream(path, FileMode.Append);

                using (StreamWriter writing = new StreamWriter(stream))
                {
                   writing.WriteLine(content);

                }

                using(StreamReader reader = new StreamReader(path))
                {
                    string fileContent = reader.ReadToEnd();

                }
            }

         }

        private void btnCountofUsers_Click(object sender, EventArgs e)
        {
            string path = @"C:\Users\1896192\Desktop\Mahnaz\User.txt";

           // string fileContent = string.Empty;
            var line = 0;
            
           // FileStream stream = new FileStream(path, FileMode.Append);

            using (StreamReader reading = new StreamReader(path)) {

                //fileContent = reading.ReadLine();

                while (reading.ReadLine() != null)
                {
                    line++;                                

                }

                MessageBox.Show("the line is " + line);
             }
        }

        private void btnDeleteUsers_Click(object sender, EventArgs e)
        {
            string path = @"C:\Users\1896192\Desktop\Mahnaz\User.txt";

            try
            {

                File.Delete(path);

            }
            catch (Exception exc) {

             MessageBox.Show(exc.Message);
            }

         }

        private void txtFN_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
