﻿namespace ExamForm
{
    partial class frmRegist
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFN = new System.Windows.Forms.TextBox();
            this.txtLN = new System.Windows.Forms.TextBox();
            this.txtTelNo = new System.Windows.Forms.TextBox();
            this.lblFN = new System.Windows.Forms.Label();
            this.lblLastN = new System.Windows.Forms.Label();
            this.lblTelNo = new System.Windows.Forms.Label();
            this.btnClearF = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.btnCountofUsers = new System.Windows.Forms.Button();
            this.btnDeleteUsers = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtFN
            // 
            this.txtFN.Location = new System.Drawing.Point(226, 104);
            this.txtFN.Name = "txtFN";
            this.txtFN.Size = new System.Drawing.Size(266, 20);
            this.txtFN.TabIndex = 0;
            this.txtFN.TextChanged += new System.EventHandler(this.txtFN_TextChanged);
            // 
            // txtLN
            // 
            this.txtLN.Location = new System.Drawing.Point(227, 179);
            this.txtLN.Name = "txtLN";
            this.txtLN.Size = new System.Drawing.Size(266, 20);
            this.txtLN.TabIndex = 1;
            // 
            // txtTelNo
            // 
            this.txtTelNo.Location = new System.Drawing.Point(227, 252);
            this.txtTelNo.Name = "txtTelNo";
            this.txtTelNo.Size = new System.Drawing.Size(265, 20);
            this.txtTelNo.TabIndex = 2;
            // 
            // lblFN
            // 
            this.lblFN.AutoSize = true;
            this.lblFN.Location = new System.Drawing.Point(102, 107);
            this.lblFN.Name = "lblFN";
            this.lblFN.Size = new System.Drawing.Size(55, 13);
            this.lblFN.TabIndex = 3;
            this.lblFN.Text = "First name";
            // 
            // lblLastN
            // 
            this.lblLastN.AutoSize = true;
            this.lblLastN.Location = new System.Drawing.Point(101, 179);
            this.lblLastN.Name = "lblLastN";
            this.lblLastN.Size = new System.Drawing.Size(56, 13);
            this.lblLastN.TabIndex = 4;
            this.lblLastN.Text = "Last name";
            // 
            // lblTelNo
            // 
            this.lblTelNo.AutoSize = true;
            this.lblTelNo.Location = new System.Drawing.Point(101, 255);
            this.lblTelNo.Name = "lblTelNo";
            this.lblTelNo.Size = new System.Drawing.Size(96, 13);
            this.lblTelNo.TabIndex = 5;
            this.lblTelNo.Text = "Telephone number";
            // 
            // btnClearF
            // 
            this.btnClearF.Location = new System.Drawing.Point(227, 309);
            this.btnClearF.Name = "btnClearF";
            this.btnClearF.Size = new System.Drawing.Size(93, 23);
            this.btnClearF.TabIndex = 6;
            this.btnClearF.Text = "clear Form";
            this.btnClearF.UseVisualStyleBackColor = true;
            this.btnClearF.Click += new System.EventHandler(this.btnClearF_Click);
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(388, 309);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(87, 23);
            this.btnRegister.TabIndex = 7;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // btnCountofUsers
            // 
            this.btnCountofUsers.Location = new System.Drawing.Point(227, 369);
            this.btnCountofUsers.Name = "btnCountofUsers";
            this.btnCountofUsers.Size = new System.Drawing.Size(93, 23);
            this.btnCountofUsers.TabIndex = 8;
            this.btnCountofUsers.Text = "Count of users";
            this.btnCountofUsers.UseVisualStyleBackColor = true;
            this.btnCountofUsers.Click += new System.EventHandler(this.btnCountofUsers_Click);
            // 
            // btnDeleteUsers
            // 
            this.btnDeleteUsers.Location = new System.Drawing.Point(388, 369);
            this.btnDeleteUsers.Name = "btnDeleteUsers";
            this.btnDeleteUsers.Size = new System.Drawing.Size(87, 23);
            this.btnDeleteUsers.TabIndex = 9;
            this.btnDeleteUsers.Text = "Delete users";
            this.btnDeleteUsers.UseVisualStyleBackColor = true;
            this.btnDeleteUsers.Click += new System.EventHandler(this.btnDeleteUsers_Click);
            // 
            // frmRegist
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnDeleteUsers);
            this.Controls.Add(this.btnCountofUsers);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.btnClearF);
            this.Controls.Add(this.lblTelNo);
            this.Controls.Add(this.lblLastN);
            this.Controls.Add(this.lblFN);
            this.Controls.Add(this.txtTelNo);
            this.Controls.Add(this.txtLN);
            this.Controls.Add(this.txtFN);
            this.Name = "frmRegist";
            this.Text = "Register";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtFN;
        private System.Windows.Forms.TextBox txtLN;
        private System.Windows.Forms.TextBox txtTelNo;
        private System.Windows.Forms.Label lblFN;
        private System.Windows.Forms.Label lblLastN;
        private System.Windows.Forms.Label lblTelNo;
        private System.Windows.Forms.Button btnClearF;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.Button btnCountofUsers;
        private System.Windows.Forms.Button btnDeleteUsers;
    }
}

