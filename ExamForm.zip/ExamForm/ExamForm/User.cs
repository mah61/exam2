﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamForm
{
    class User
    {
        private string fname;
        private string lname;
        private string tel;

        public User() {
        }


        public User(string fname, string lname, string tel) {

            this.fname = fname;
            this.lname = lname;
            this.tel = tel;
    
    }

        public string GetFName() {

            return fname;
        }


        public void SetFName(string fname) {

            this.fname = fname;

        }

        public string GetLName()
        {

            return lname;
        }

        public void SetLName(string lname)
        {

            this.lname = lname;

        }

        public string GetTel()
        {

            return tel;
        }

        public void SetTel(string tel)
        {

            this.tel = tel;

        }
        
    }
}
